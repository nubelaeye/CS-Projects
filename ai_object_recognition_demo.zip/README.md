# AI Object Recognition Demo (CIFAR-10)

This folder contains a minimal project that trains a small CNN on CIFAR-10 and exposes a Gradio web demo.

**Files included**
- train_model.py : Train a simple CNN on CIFAR-10 and save `object_recognition_model.h5`
- app.py : Gradio app that loads `object_recognition_model.h5` and offers webcam/upload prediction
- requirements.txt : Python dependencies
- generate_qr.py : Generate QR codes for your deployed Space URL
- README.md : This file

**Quick setup & run (local)**
1. Create a Python virtual environment (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate      # on macOS/Linux
   venv\Scripts\activate       # on Windows (PowerShell)
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Train the model (creates `object_recognition_model.h5`):
   ```bash
   python train_model.py
   ```
   (Training uses CIFAR-10 and will take several minutes depending on your machine. You can change epochs in the file.)

4. Run the demo locally:
   ```bash
   python app.py
   ```
   Open the printed local URL (usually http://127.0.0.1:7860) and try the webcam or upload.

**Deploy to Hugging Face Spaces (Gradio)**
1. Create a new Space (SDK = Gradio). Upload the files in this folder to the Space repository.
2. If you didn't train locally, upload `object_recognition_model.h5` after training.
3. After the build finishes, your Space will have a public URL. Use `generate_qr.py` to create a QR code:
   ```bash
   python generate_qr.py https://huggingface.co/spaces/<YOUR_USERNAME>/<SPACE_NAME>
   ```

**Notes & next steps**
- CIFAR-10 is small and used here for demonstration. For real-world objects, use transfer learning on a larger, custom dataset.
- For object detection (multiple objects with boxes), consider YOLO or TensorFlow Object Detection API.
- If you want, I can add a pretrained MobileNet-based classifier and a more polished UI for the Space.
