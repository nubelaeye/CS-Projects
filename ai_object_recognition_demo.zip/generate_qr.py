    # generate_qr.py
    # Generates a QR code image that points to the deployed Hugging Face Space URL.
    import qrcode
    import sys

    def make_qr(url, out='object_recognition_qr.png'):
        qr = qrcode.QRCode(
            version=2,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=10,
            border=4,
        )
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        img.save(out)
        print(f"Saved QR code to {out}")

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python generate_qr.py <URL> [output_file]")
    else:
        url = sys.argv[1]
        out = sys.argv[2] if len(sys.argv) > 2 else 'object_recognition_qr.png'
        make_qr(url, out)
