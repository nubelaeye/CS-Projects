# app.py
# Gradio app that loads the trained model and provides an upload/webcam interface.
import gradio as gr
import tensorflow as tf
import numpy as np
from PIL import Image
import os

MODEL_PATH = "object_recognition_model.h5"

labels = [
    'airplane', 'automobile', 'bird', 'cat', 'deer',
    'dog', 'frog', 'horse', 'ship', 'truck'
]

def load_model():
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model file '{MODEL_PATH}' not found. Run 'python train_model.py' first to create it.")
    model = tf.keras.models.load_model(MODEL_PATH)
    return model

model = None
try:
    model = load_model()
except Exception as e:
    print("Warning:", e)
    # The Space will still build; running the app without model will show an error message instructing to train/upload.

def predict(image):
    if model is None:
        return "Model not loaded. Please run training (train_model.py) locally and upload the resulting 'object_recognition_model.h5' to this Space."
    # Preprocess
    image = Image.fromarray(image).resize((32,32)).convert('RGB')
    img_array = np.expand_dims(np.array(image) / 255.0, axis=0)
    preds = model.predict(img_array)
    idx = int(np.argmax(preds))
    confidence = float(np.max(preds)) * 100.0
    return {labels[i]: float(preds[0][i]) for i in range(len(labels))}

title = "AI Object Recognition Demo (CIFAR-10)"
description = "Upload an image or use your webcam. The model predicts probabilities for 10 CIFAR-10 classes.\n\nNOTE: If the model is not present, run 'python train_model.py' and upload the saved 'object_recognition_model.h5' to this Space."

with gr.Blocks() as demo:
    gr.Markdown(f"# {title}")
    gr.Markdown(description)
    with gr.Row():
        inp = gr.Image(source='webcam', type='numpy', tool='editor')
        out = gr.Label(num_top_classes=3)
    btn = gr.Button("Predict")
    btn.click(fn=predict, inputs=inp, outputs=out)
    gr.Markdown("---\n**How to prepare model:** Run `python train_model.py` locally to create 'object_recognition_model.h5' then upload it to this Space (or copy it into the folder before pushing)." )

if __name__ == '__main__':
    demo.launch()
